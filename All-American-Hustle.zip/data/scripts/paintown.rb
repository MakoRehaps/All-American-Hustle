def foobar
    puts PaintownInternal.register(2)
    4
end
